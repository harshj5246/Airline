﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace appWpfDBOne
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            product = new Product(1001, "Lux 50gm", 40, 45);
            MyLayout.DataContext = product; //this.DataContext = product;
            YourLayout.DataContext = product;
            //assign the property of the object to ui
            //txtProductId.Text = product.ProductId.ToString()
            ThirdLayout.DataContext = this;
            

        }
        private Product product;

        private string windowTitle="My Page";
        public string OurWindowTitle
        {
            get { return windowTitle; }
            set { windowTitle = value; }
        }
    }
}

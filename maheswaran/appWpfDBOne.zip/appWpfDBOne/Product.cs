﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appWpfDBOne
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Qty { get; set; }
        public double Price { get; set; }

        public Product():this(0,string.Empty,0,0)
        {

        }
        public Product(int productId, string productName, int qty, double price)
        {
            this.ProductId = productId;
            this.ProductName = productName;
            this.Qty = qty;
            this.Price = price;
        }
    }
}
